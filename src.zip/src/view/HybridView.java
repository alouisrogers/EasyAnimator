package view;

import java.awt.Component;
import java.awt.BorderLayout;
import java.util.List;

import javax.swing.*;
import javax.swing.event.ChangeListener;

import model.shapes.Shape;

/**
 * Interactive SVG and Visual view which can export the animation to an SVG file,
 * and can create a visual display of the animation. This view can also interact with the user.
 * It allows the user to start, pause, resume and rewind the animation, enable looping, adjust
 * the speed of the animation as it is being played, and export on command to an SVG file.
 */
public class HybridView extends GUIView implements IVisualView {
  JLabel lineBorderLabel;
  JSlider frame;


  public HybridView() {
    super();
    this.lineBorderLabel = new JLabel();
    this.remove(this.scrollPane);
    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
    JPanel panel = new JPanel();
    panel.setBorder(BorderFactory.createTitledBorder("Key"));
    JLabel key = new JLabel("<html> -'space' to start animation <br>-'p': "
        + "&nbsp Play/Pause &nbsp&nbsp&nbsp&nbsp&nbsp  "
        + "-'l': &nbsp Enable/Disable loop &nbsp&nbsp&nbsp&nbsp&nbsp "
        + "-'r': &nbsp Rewind to <br>-'up/down': &nbsp increase/decrease speed "
        + " &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"
        + "&nbsp&nbsp&nbsp&nbsp -'left/right': &nbsp Fast forward/Rewind line</html>");
    panel.add(key);
    mainPanel.add(panel);
    mainPanel.add(this.scrollPane);
    this.add(mainPanel);
  }

  public void svgExport(List<Shape> shapeList, int ticksPerSecond, String outputMode,
      boolean hasLoop) throws IllegalArgumentException {
    if (shapeList == null || outputMode == null) {
      throw new IllegalArgumentException("Null field given.");
    }
    if (ticksPerSecond < 1) {
      throw new IllegalArgumentException("Need positive ticks per second.");
    }
    if (!outputMode.endsWith(".svg")) {
      throw new IllegalArgumentException("Must export to an svg file.");
    }

    SVGView svgView = new SVGView();

    svgView.renderText(shapeList, ticksPerSecond, outputMode, new StringBuffer(), hasLoop);
  }

  /**
   * Reset the focus on the appropriate part of the view that has the keyboard listener attached to
   * it, so that keyboard events will still flow through.
   */
  public void resetFocus() {
    this.setFocusable(true);
    this.requestFocus();
  }

  public void addStatusBar(boolean pause, boolean loop, int speed) {
    String pauseStatus;
    String loopStatus;

    if (pause) {
      pauseStatus = "Paused";
    }
    else {
      pauseStatus = "Playing";
    }
    if (loop) {
      loopStatus = "Looping";
    }
    else {
      loopStatus = "No loop";
    }

    lineBorderLabel.setText("Status: " + pauseStatus + "      Loop Status: " + loopStatus
        + "      FPS: " + speed);
    this.add(lineBorderLabel, BorderLayout.NORTH);
    this.repaint();
  }

  public void updateLabel(boolean pause) {
    this.lineBorderLabel.setText("pause : " + pause);
  }


  public void addSlideListener(ChangeListener slider, int ticks) {
    this.frame = new JSlider(JSlider.HORIZONTAL, 0, ticks, 0);
    frame.setAlignmentX(Component.CENTER_ALIGNMENT);
    frame.setMinorTickSpacing(ticks / 50);
    frame.setMajorTickSpacing(25);
    frame.setPaintLabels(true);
    frame.setPaintTicks(true);
    this.add(frame, BorderLayout.SOUTH);
    this.frame.addChangeListener(slider);
    this.validate();
    this.repaint();
  }
}
