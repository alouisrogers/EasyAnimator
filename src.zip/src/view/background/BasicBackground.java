package view.background;

import java.awt.Color;

public class BasicBackground implements IBackground {

  Color color;

  public BasicBackground(Color color) {
    this.color = color;
  }

  @Override
  public Color getColor() {
    return this.color;
  }
}
