package view.background;

import java.awt.Color;

public interface IBackground {
  Color getColor();
}
