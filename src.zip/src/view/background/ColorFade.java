package view.background;

import java.awt.Color;

public class ColorFade implements IBackground{

  Color start;
  Color end;
  Color curr;

  ColorFade(Color start, Color end) {
    this.start = start;
    this.curr = start;
    this.end = end;
  }


  @Override
  public Color getColor() {
    return Color.BLUE;
  }
}
