package view.background;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ColorCycle implements IBackground{
  List<Color> colorList = new ArrayList<>();

  public ColorCycle(List<Color> colorList) {
    this.colorList = colorList;
  }

  int tickRate = 0;
  int colorChange = 0;

  @Override
  public Color getColor() {
    if (tickRate % 75 == 0) {
      colorChange++;
      if (colorChange >= colorList.size()) {
        this.colorChange = 0;
      }
      tickRate++;
      Color curr = colorList.get(colorChange);
      return curr;
    }
    tickRate++;
    return colorList.get(colorChange);
  }
}
